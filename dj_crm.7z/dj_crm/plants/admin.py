from django.contrib import admin
from .models import Plants

admin.site.register(Plants)


