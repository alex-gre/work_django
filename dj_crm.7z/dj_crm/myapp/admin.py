from django.contrib import admin
from .models import Contacts

# Register your models here.



admin.site.register(Contacts)
