create table castomer(

   id integer primary key autoincrement,
   name varchar(255),
   phone varchar(30),
   email varchar(255)
   ); 