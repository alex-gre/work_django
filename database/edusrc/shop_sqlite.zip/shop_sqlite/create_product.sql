create table product(
  id integer primary key autoincrement ,
  name varchar(255),
  description text,
  price integer
);