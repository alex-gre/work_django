from django.db import models

# Create model Contacts

class Contacts(models.Model):

    company_address = models.CharField('Address ',max_length=200)
    link1 = models.CharField('Links1 ',max_length=200)
    email = models.EmailField('Email ',max_length=200)
    phone = models.CharField('Phone ',max_length=22)
    def __str__(self):
        return f'Addr. - {self.company_address} - Pnone -{self.phone} - Email {self.email}'

    class Meta:
        verbose_name = 'Контакт'
        verbose_name_plural = 'Контакты'  
        