from django.urls import path
from . import views



urlpatterns = [
    path('', views.plants_home, name='plants_home'),
    #path('create', views.create, name='create'),
    #path('<int:pk>', views.NewsDetailView.as_view(), name='plants-detail')
    
]


