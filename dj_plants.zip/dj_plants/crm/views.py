from django.shortcuts import render
from .models import Client, Order, Communication

# Create your views here.
def crm_home(request):
    crm = Order.objects.all()
    return render(request,'crm/crm_home.html',{'crm':crm})