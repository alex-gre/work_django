from django.urls import path
from . import views


urlpatterns = [
    path('crm_home', views.crm_home, name='crm_home'),
]