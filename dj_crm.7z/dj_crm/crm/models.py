import datetime
from django.db import models
from django.utils import timezone

# Клиенты
class Client(models.Model):
    # ФИО клиента
    full_name = models.CharField(max_length=200)
    # Дата регистрации клиента
    reg_date = models.DateTimeField("Дата регистрации")
    
    def __str__(self):
        return f'{self.full_name}'

# Заказы клиентов
class Order(models.Model):
        
    # Привязка к клиенту
    client = models.ForeignKey(Client, on_delete=models.CASCADE)
    # Описание заказа
    descr = models.CharField(max_length=200) 
    # Адрес доставки
    address = models.CharField(max_length=200)
    # Стоимость заказа
    votes = models.DecimalField("Стоимость заказа", max_digits=5, decimal_places=2)
    # Факт оплаты заказа
    is_paid = models.BooleanField("Заказ оплачен?", default=False)
    # Дата создания заказа
    pub_date = models.DateTimeField("Дата создания", auto_now_add=True)
    
    def __str__(self):
        return f'Заказ №{self.id} - {self.client} - {self.address} - {self.pub_date}'

# Коммуникации с клиентами
# (когда кому последний раз звонили и о чём договорились)
class Communication(models.Model):
    # Привязка к клиенту
    client = models.ForeignKey(Client, on_delete=models.CASCADE)
    # О чём договорились с клиентом
    text = models.CharField(max_length=200) 
    # Дата коммуникации
    pub_date = models.DateTimeField("Дата коммуникации", auto_now_add=True)
    
    def __str__(self):
        return f'Коммуникация №{self.id} - {self.client} - {self.text}'
