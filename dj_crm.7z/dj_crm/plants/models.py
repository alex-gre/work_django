import datetime
from django.db import models
from django.utils import timezone

# Производство
class Plants(models.Model):

    #product_id = models.ForeignKey(Plants, on_delete=models.CASCADE)
    # имя продукта 'растения'
    full_name = models.CharField(max_length=100)
    latin_name = models.CharField(max_length=800)
    # Дата регистрации клиента
    reg_date = models.DateTimeField("Дата создания")
    end_date = models.DateTimeField("Дата создания")
    info = models.CharField(max_length=200)
    def __str__(self):
        return f'{self.full_name}'


    class Meta:
        verbose_name = 'Производство'
        verbose_name_plural = 'Производство'
         

