from django.contrib import admin
from .models import Client, Order, Communication

admin.site.register(Client)
admin.site.register(Order)
admin.site.register(Communication)
