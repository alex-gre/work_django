
from django.shortcuts import render, redirect
from .models import Contacts
#from .forms import ArticlesForm



  

data = {
       'title':'Главная страница'
}

def home(request):  
    
    return render(request,'myapp/index.html', data)

def about(request):
       return render(request,'myapp/about.html')

def contacts(request):
       contacts = Contacts.objects.all()
       return render(request,'myapp/contacts.html',{'contacts':contacts})
       #return render(request,'myapp/contacts.html')

