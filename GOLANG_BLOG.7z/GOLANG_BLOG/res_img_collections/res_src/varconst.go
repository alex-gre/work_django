package main

import (
	"fmt"
	"os"
)

func main() {
	const pi = 3.14
	var i int16
	i = 5
	name := "John"
	var name2, age = "Tom", 27
	var i2 int
	fmt.Println("variable i = ", i)
	fmt.Println("Hello, " + name)
	fmt.Println("Hello, "+name2+" age ", age)
	fmt.Println("Dig pi =  ", pi)
	fmt.Fscan(os.Stdin, &i2)
	fmt.Println(i2)

}
