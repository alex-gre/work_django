
from django.shortcuts import render, redirect
from .models import Plants
from .views import Plants

def plants_home(request):

    plants = Plants.objects.all()
    return render(request,'plants/plants_home.html',{'plants':plants})